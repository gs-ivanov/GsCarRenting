﻿namespace CarRentingSystem.Models.Cars
{
    public class CarCategoryViewModel
    {
        public int Id { get; init; }

        public string Name { get; init; }
    }
}
